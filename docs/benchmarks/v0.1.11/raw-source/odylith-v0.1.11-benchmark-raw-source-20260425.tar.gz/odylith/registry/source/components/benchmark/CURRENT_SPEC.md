# Benchmark

## Odylith Discipline Contract
- Benchmark owns Product Truth for Odylith Discipline. The
  `discipline` family measures hard laws, unknown pressure,
  mixed pressure, learning replay, false allow/block behavior, intervention
  precision, zero-credit hot paths, and public-claim gating.
- Quick family proof stays local-only; public/release claims require full
  matched proof with `odylith_on` versus `raw_agent_baseline`, fairness intact,
  warm and cold profiles, and pinned dogfood runtime health.
- The family includes a critical host/lane parity scenario so Codex and Claude
  across dev, dogfood, and consumer lanes are benchmark-visible. Host model
  aliases remain adapter metadata; hot Odylith Discipline proof requires zero host model
  and provider calls.
- Odylith Discipline validation is a platform contract, not only corpus parsing: it
  checks declared proof obligations, affordance ranking, intervention
  visibility, learning/memory signals, zero-credit budget counters, bundle
  mirrors, and cross-layer integration tokens before benchmark summaries can
  report clean Odylith Discipline metrics.
- Odylith Discipline metrics now include deterministic false allow/block rates,
  unknown-pressure handling, stance-vector coverage, noise-suppression,
  intervention precision, and unseen-pressure generalization alongside
  hot-path provider and host-model call counts.
- Odylith Discipline corpus coverage includes false-block guards for
  allowed technical-plan authoring, release-proof execution, credit-safety
  hardening, negated delegation, and modern Codex/Claude model-alias
  normalization.
- Guidance Behavior and Odylith Discipline quick scenarios are tagged
  to B-110 so program/release proof and benchmark adoption metrics carry the
  same workstream anchor. A missing B-110 anchor is treated as benchmark
  corpus drift because it can create false `requires_widening` advisory noise
  even when required-path recall and validation are green.
Last updated: 2026-04-18


Last updated (UTC): 2026-04-18

## Purpose
Benchmark is Odylith's local proof subsystem for measuring whether Odylith-on
actually makes agentic coding better than the true `odylith_off` /
`raw_agent_baseline` lane, while still measuring the secondary repo-scan
scaffold control lane. It owns the benchmark corpus, the
runner and publication contract, the generated benchmark report ledger, the
maintained graph pipeline used in README and release proof, and the public
reviewer framing that explains how Odylith should be compared.

## Scope And Non-Goals
### Benchmark owns
- The tracked benchmark corpus in
  `odylith/runtime/source/optimization-evaluation-corpus.v1.json`.
- Local benchmark execution and conservative publication logic in
  `src/odylith/runtime/evaluation/odylith_benchmark_runner.py`.
- Maintained benchmark graph generation in
  `src/odylith/runtime/evaluation/odylith_benchmark_graphs.py`.
- Public benchmark framing and reviewer guidance under `docs/benchmarks/`.
- Local benchmark history under `.odylith/runtime/odylith-benchmarks/`.
- The release-safe benchmark publication contract used by README and maintainer
  release proof.
- Advisory mechanism reports that support release proof without pretending to
  be full `odylith_on` outcome proof. The v0.1.11 visible intervention value
  report lives in
  `src/odylith/runtime/evaluation/odylith_intervention_value_engine_benchmark.py`
  and evaluates the governed bootstrap corpus only as selector mechanism
  evidence.

### Benchmark does not own
- The grounding, routing, or orchestration runtime it measures.
- Hosted evaluation infrastructure.
- Consumer-repo source truth outside the local Odylith tree.
- Host-native benchmark claims that do not share the current matched proof
  harness.
- Runtime claims that a sparse or synthetic corpus is ML-calibrated. Benchmark
  may report `corpus_quality_state=bootstrap` and `calibration_publishable`,
  but only a publishable non-synthetic adjudication corpus can support
  calibration claims.

## Developer Mental Model
- The corpus defines the scenarios, expectations, and validation hooks that
  Odylith must beat honestly.
- The runner executes those scenarios across multiple cache profiles and modes,
  then publishes a conservative same-scenario comparison instead of the easiest
  green snapshot.
- `odylith_on` measures the real full-product Odylith assistance stack.
- `odylith_on_no_fanout` isolates how much bounded multi-leaf orchestration is
  contributing on top of the same full-product Odylith assistance lane.
- `raw_agent_baseline` is `odylith_off`, or plain-English `Odylith off`: the
  raw host CLI control with Odylith grounding disabled.
- `odylith_repo_scan_baseline` is the current repo-scan scaffold control lane.
- The honest primary benchmark comparison is `odylith_on` versus
  `raw_agent_baseline`, and the public comparison contract for that pair is
  `full_product_assistance_vs_raw_agent`; the repo-scan lane is secondary
  context that shows how much scaffolding helps.
- The benchmark now also owns a developer-first family taxonomy in
  `src/odylith/runtime/evaluation/odylith_benchmark_taxonomy.py`. That
  taxonomy orders the public README table and both proof and diagnostic family
  heatmaps by developer legibility rather than by prompt-cost ranking.
- The tracked corpus now includes a dedicated `live_proof_discipline` family
  for proof-state control-panel behavior. That family measures whether
  benchmark packets expose a real live blocker lane when one resolves and stay
  explicit about `none` when no lane resolves.
- The tracked corpus now also includes a dedicated
  `context_engine_grounding` family for Context Engine packet-lane and
  scope-resolution behavior. That family measures whether adaptive and
  governance packets choose the right lane, keep the right workstream anchor,
  and stay fail-closed on broad or unresolved scope.
- The tracked corpus now also includes a dedicated
  `execution_engine` family for Execution Engine contract posture and
  honest guardrail proof. That family measures whether packets and runtime
  summaries preserve the real `admit|deny|defer` decision, mode, next move,
  closure posture, wait/resume state, validation archetype, host family,
  target lane, delegation or parallelism guard posture, and fail-closed
  recovery shape instead of collapsing back to stale or generic route hints.
- The tracked corpus now also includes a dedicated `guidance_behavior` family
  for high-risk guidance pressure cases. That family measures whether agents
  ground before broad scans, obey CLI-first governed truth, avoid adopting
  queued work without explicit instruction, qualify completion claims with
  fresh proof, bound delegation contracts, and distinguish hidden
  intervention payloads from chat-visible proof.
- The tracked corpus now tags `guidance_behavior` and
  `discipline` quick scenarios to B-110 so the v0.1.11 program
  is visible to benchmark selection, adoption summaries, and advisory widening
  checks.
- Proof-discipline summary metrics are first-class benchmark outputs now:
  `proof_state_present_rate`, `false_clearance_rate`,
  `proof_frontier_gate_accuracy_rate`, `proof_claim_guard_accuracy_rate`, and
  `proof_same_fingerprint_reuse_rate`.
- Context Engine grounding summary metrics are first-class benchmark outputs
  now too: `context_engine_packet_source_accuracy_rate`,
  `context_engine_selection_state_accuracy_rate`,
  `context_engine_workstream_accuracy_rate`,
  `context_engine_fail_closed_ambiguity_rate`, and
  `context_engine_session_namespace_rate` when runtime-backed rows are present.
- Execution Engine summary metrics are first-class benchmark outputs now too:
  `execution_engine_present_rate`,
  `execution_engine_resume_token_present_rate`,
  `execution_engine_outcome_accuracy_rate`,
  `execution_engine_mode_accuracy_rate`,
  `execution_engine_next_move_accuracy_rate`,
  `execution_engine_closure_accuracy_rate`,
  `execution_engine_wait_status_accuracy_rate`,
  `execution_engine_validation_archetype_accuracy_rate`,
  `execution_engine_current_phase_accuracy_rate`,
  `execution_engine_last_successful_phase_accuracy_rate`,
  `execution_engine_authoritative_lane_accuracy_rate`,
  `execution_engine_target_lane_accuracy_rate`,
  `execution_engine_resume_token_accuracy_rate`,
  `execution_engine_host_family_accuracy_rate`,
  `execution_engine_model_family_accuracy_rate`,
  `execution_engine_component_id_accuracy_rate`,
  `execution_engine_canonical_component_id_accuracy_rate`,
  `execution_engine_identity_status_accuracy_rate`,
  `execution_engine_target_component_status_accuracy_rate`,
  `execution_engine_snapshot_reuse_status_accuracy_rate`,
  `execution_engine_reanchor_accuracy_rate`,
  `execution_engine_delegation_guard_accuracy_rate`, and
  `execution_engine_parallelism_guard_accuracy_rate` when execution-backed rows
  are present.
- Execution Engine cost metrics are measured as lower-is-better diagnostics:
  `execution_engine_median_context_packet_build_ms`,
  `execution_engine_median_snapshot_duration_ms`,
  `execution_engine_median_prompt_bundle_tokens`,
  `execution_engine_median_runtime_contract_tokens`, and
  `execution_engine_median_total_payload_tokens`.
- Intervention Value Engine advisory metrics are measured separately from the
  full-product benchmark: visible-block precision, must-surface recall,
  duplicate visible rate, visibility-failure recall, no-output accuracy, p95
  selector latency, corpus quality state, and calibration publishability. These
  are mechanism-health signals, not a substitute for paired `odylith_on` vs
  `odylith_off` outcome lift.
- A live `odylith_on` versus `odylith_off` comparison only counts as benchmark
  proof when both lanes run the same host CLI model, reasoning effort,
  sandbox policy, approval posture, validator contract, and stripped workspace
  shape for the proof host under test. The intended lane difference is the
  declared Odylith product assistance stack, not a hidden side channel:
  grounding packet, selected docs and repo anchors, Execution Engine posture
  and truthful next-move guidance, scenario-declared focused-check
  shaping, preflight focused-check results only when those checks run in the
  disposable benchmark workspace and are logged in the report, and bounded
  orchestration or recovery policy.
- The report under `.odylith/runtime/odylith-benchmarks/latest.v1.json` is the
  machine-readable source of truth for publication.
- That report must expose the comparison contract and fairness state
  explicitly, including `comparison_contract.primary_claim`,
  `comparison_contract.odylith_on_affordances`,
  `comparison_contract.raw_agent_affordances`,
  `preflight_evidence_mode`, `preflight_evidence_commands`,
  `preflight_evidence_result_status`, `observed_path_sources`,
  `validator_status_basis`, `fairness_contract_passed`,
  `fairness_findings`, and `corpus_composition`.
- The current report contract keeps `comparison_contract` as the stable
  comparison token and carries the structured affordance details in
  `comparison_contract_details`. Publication docs may render those details as
  `comparison_contract.primary_claim`,
  `comparison_contract.odylith_on_affordances`, and
  `comparison_contract.raw_agent_affordances`, but the machine-readable report
  must preserve both the stable token and the explicit affordance mapping.
- Packet-only diagnostic scenarios may attach a bounded `benchmark.packet_fixture`
  to restore missing proof, routing, external-state, or context fields when the
  scenario is explicitly measuring packet or runtime-summary carry-through
  instead of re-running the whole live host path. Those fixtures are
  non-publication scaffolding only: they must stay whitelisted, additive,
  scenario-local, and unable to inject hidden repo truth outside the declared
  packet payload seam.
- When focused preflight evidence is what turns a no-op lane into a validator
  pass, the result must say so explicitly through
  `validator_status_basis=focused_noop_proxy` instead of looking like a normal
  broad-validator success.
- The README numbers, benchmark explainer, reviewer guide, and canonical SVG
  graphs are derived outputs. They must never outrun the latest validated
  published report or drift away from the benchmark priority order.
- If maintainers explicitly waive proof for one release, that exception must
  be tracked in `odylith/runtime/source/release-maintainer-overrides.v1.json`
  and treated as an advisory downgrade, not as hidden benchmark success.
- Odylith's public benchmark story is benchmark-first: memory, topology,
  governance surfaces, and orchestration are mechanisms that explain the
  execution delta, not the primary scorecard.
- Simulation, reviewer, and closeout artifacts should suppress mid-analysis
  Odylith brand narration. If a writeup or agent handoff names Odylith
  directly beyond lane labels, reserve that for one short end-of-work
  `Odylith Assist:` line, and prefer `**Odylith Assist:**` when Markdown
  formatting is available. Follow the detailed closeout contract in
  [Odylith Chatter](../odylith-chatter/CURRENT_SPEC.md) and keep benchmark
  storytelling anchored in measured proof rather than duplicated branding
  rubric.
- That closeout rule is metadata-only for benchmark families: do not add
  benchmark required paths, hot-path docs, or validation commands just to
  repeat the chatter contract.

## Current Published Posture

- Latest published proof report:
  `.odylith/runtime/odylith-benchmarks/latest.v1.json`
  report `52aa3f76538cf12f`, status `provisional_pass`
- Latest published diagnostic report:
  `.odylith/runtime/odylith-benchmarks/latest-diagnostic.v1.json`
  report `74cbe36427f2c375`, status `hold`
- Current published proof deltas versus `odylith_off`:
  `+0.227` recall, `+0.168` precision, `-0.141` hallucinated-surface rate,
  `+0.069` validation success, `+0.330` critical recall,
  `+0.167` critical validation success, `+0.393` expectation success,
  `+0.124` write-surface precision, `-0.170` unnecessary widening,
  `-52,561` median live-session input tokens, `-53,774` median total model
  tokens, and `-12.427s` median time to valid outcome
- Current proof hard-gate blockers:
  none on the current full warm-plus-cold proof
- Current proof secondary guardrails:
  both cache profiles clear the hard gate and `within_budget_rate` is back
  above the `0.80` floor
- Current proof attention families:
  `architecture`, `browser_surface_reliability`, `component_governance`,
  `cross_surface_governance_sync`, `governed_surface_sync`, and
  `orchestration_feedback`
- Current proof memory posture:
  local-memory-first on LanceDB plus Tantivy, with Vespa intentionally
  disabled unless a run explicitly reports otherwise
- Product-repo release-baseline posture:
  the current passing proof is detached `source-local` posture, and
  `benchmark_compare` still reports `warn` until there is a last-shipped
  published release baseline in `docs/benchmarks/release-baselines.v1.json`
- Active release exception:
  `v0.1.10` currently carries a tracked `skip_proof_and_compare` override
  because pinned-dogfood proof run `0047192366d8bf1c` wedged mid-corpus and
  did not persist a fresh release-safe report. That exception is exact-version
  only and moves benchmark runner tuning plus proof restoration to the next
  release.

## Current Benchmark Priorities

- Keep the current `52aa3f76538cf12f` full proof as the new source-local
  floor and reject regressions against its quality, validation, and budget
  wins.
- Preserve bounded benchmark finalization: adoption-proof sampling is
  supplementary and must degrade cleanly on timeout or transport loss instead
  of blocking report persistence after the full corpus finishes.
- Keep proof-state benchmark slices honest: `false_clearance_rate` must stay at
  `0.0`, and proof-backed benchmark rows must keep frontier gating plus
  claim-tier accuracy at `1.0`.
- Keep Context Engine benchmark slices honest: packet-lane accuracy,
  selection-state accuracy, workstream accuracy, and ambiguity fail-closed
  behavior must stay at `1.0` whenever the sampled corpus includes those rows.
- Keep Execution Engine benchmark slices honest: Execution Engine
  presence, resume-token presence, outcome accuracy, mode accuracy, truthful
  next-move accuracy, closure accuracy, wait/resume accuracy, host-family
  accuracy, target-lane accuracy, guard accuracy, canonical identity accuracy,
  snapshot-reuse posture, and authoritative-lane accuracy must stay at `1.0`
  whenever the sampled corpus includes those rows.
- Keep the first shipped release proof local-memory-first; hybrid rerank and
  remote retrieval remain experiment lanes until they improve proof without
  harming the current pass.
- Convert the current source-local pass into a pinned-dogfood release proof and
  then record the first shipped release baseline in
  `docs/benchmarks/release-baselines.v1.json`.
- Continue driving the advisory families down without giving back the current
  proof or the `74cbe36427f2c375` diagnostic grounding wins.

## Developer-First Taxonomy

Benchmark publication now leads with the developer-facing core:

- Bug Fixes
- Multi-File Features
- Runtime / Install / Security
- Surface / UI Reliability
- Docs + Code Closeout
- Governance / Release Integrity, including live blocker proof discipline
- Architecture Review
- Grounding / Orchestration Control
- Execution posture is measured inside Grounding / Orchestration Control as a
  first-class family now, not as an implicit byproduct of context grounding.

That ordering is non-cosmetic. The benchmark keeps Odylith's governance and
architecture truth, but the public heatmaps and family tables should now start
with the families that look and feel most like normal coding-agent work.

## Public And Maintainer Command Surface
### Public operator entrypoint
- `odylith benchmark --repo-root .`
  Run the fast local developer lane: the honest `odylith_on` versus
  `odylith_off` matched pair on the warm cache profile plus a representative
  family-smoke subset unless the operator narrows it explicitly.
- `odylith benchmark --repo-root . --profile proof`
  Run the full strict publication lane and update `latest.v1.json` only when
  the run covers the full tracked corpus and release-safe mode or cache-profile
  matrix.
- `odylith benchmark --repo-root . --profile proof --family <family> --shard-count N --shard-index K`
  Run a deterministic strict-proof shard without changing scoring, sandbox
  isolation, or matched-pair fairness.

### Maintainer publication helpers
- `PYTHONPATH=src python -m odylith.runtime.evaluation.odylith_benchmark_graphs --report .odylith/runtime/odylith-benchmarks/latest.v1.json --out-dir docs/benchmarks`
  Regenerate the canonical README SVG graph set from the current report.
- `PYTHONPATH=src python -m odylith.runtime.evaluation.odylith_benchmark_publication --repo-root .`
  Refresh the benchmark snapshot markdown and tracked `latest-summary` JSON
  from the selected diagnostic and live reports without hand-editing the
  generated snapshot files.
- [Maintainer benchmark release guidance](../../../../maintainer/agents-guidelines/RELEASE_BENCHMARKS.md)
  defines the release-safe publication contract and graph order.

## Repository And Runtime Layout
### Tracked product truth
- `odylith/runtime/source/optimization-evaluation-corpus.v1.json`
  Canonical benchmark corpus and scenario inventory.
- `src/odylith/runtime/evaluation/odylith_benchmark_runner.py`
  Benchmark runner, aggregation, and publication logic.
- `src/odylith/runtime/evaluation/odylith_benchmark_graphs.py`
  Canonical graph renderer for the maintained README SVG set.
- `src/odylith/runtime/evaluation/odylith_benchmark_publication.py`
  Canonical publication writer for benchmark snapshot markdown and tracked
  latest-summary truth.
- `src/odylith/runtime/evaluation/odylith_benchmark_taxonomy.py`
  Canonical developer-first family ordering for README and graph publication.
- `README.md`
  Top-level public benchmark framing and current benchmark snapshot.
- `docs/benchmarks/`
  Benchmark explainer, reviewer guidance, and generated graph assets published
  in README.
- `odylith/maintainer/agents-guidelines/RELEASE_BENCHMARKS.md`
  Maintainer release-proof contract for benchmark publication.
- `odylith/maintainer/skills/release-benchmark-publishing/SKILL.md`
  Maintainer execution guidance for benchmark regeneration and release proof.

### Mutable runtime state
- `.odylith/runtime/odylith-benchmarks/latest.v1.json`
  Current benchmark report used for local inspection and publication.
- `.odylith/runtime/odylith-benchmarks/<report_id>.json`
  Historical benchmark reports retained for comparison and audit.

## Core Benchmark Contract
### Corpus truth
- Each scenario must stay tied to real repo truth, real validation hooks, and
  real expectations. The benchmark is not allowed to soften the workload just
  to improve the score.
- Workstream anchors, owned paths, and expectation surfaces must stay current
  with Radar, Registry, Atlas, and the runtime contracts they exercise.

### Integrity non-negotiable
- Never game the eval.
- Never trade recall, accuracy, or precision away just to make latency or token
  budgets look better.
- Benchmark authors must not improve Odylith's score by removing hard cases,
  loosening required paths, weakening validators, trimming cache profiles, or
  publishing hand-picked report slices.
- Benchmark publication must fail closed on stale source truth, stale runtime
  truth, or README or graph claims that outrun the conservative published
  report.
- If Odylith regresses on a more realistic or more adversarial corpus, the
  product should absorb that signal and improve; the corpus should not be
  softened to preserve flattering numbers.
- Benchmark evolution is allowed only when it makes the eval harder, more
  representative, more reproducible, or more conservative.
- A live raw-host baseline is invalid for publication if the disposable
  workspace inherits ambient workstation or repo state beyond the explicit
  shared task contract. Shared `.odylith` runtime state, global Git config,
  host Python or package-manager state, desktop host environment variables,
  shared caches, or shell startup drift all count as contamination.
- Benchmark status must fail closed when both compared lanes fail, time out, or
  miss the validator contract. Equal failure is never a pass.
- Validator-backed task success and proxy expectation success must remain
  separately labeled in reports and docs. Packet or expectation proxies are
  diagnostic signals only; they are not the same thing as confirmed validator
  completion.
- Blanket wall-clock overrides that materially distort live matched-pair runs
  are debug tools, not release-safe proof. Published reports must record the
  timeout policy that governed each live run.

### Modes and cache profiles
- The benchmark profiles are `quick`, `proof`, and `diagnostic`.
- `quick` is the default local developer lane: the public matched pair only,
  warm cache only, and representative family-smoke selection unless the
  operator passes explicit filters.
- `proof` is the release-safe publication lane: the full corpus for the live
  `odylith_on` versus `odylith_off` pair plus both `warm` and `cold` cache
  profiles unless the operator passes explicit filters.
- `diagnostic` is the internal tuning lane: it isolates packet and prompt
  creation for `odylith_on` versus `odylith_off` without running the live
  end-to-end host pair.
- The proof lane answers:
  - "Does the full Odylith assistance stack beat the raw host CLI on the same live end-to-end task contract?"
  - "What is the full matched-pair time to valid outcome?"
  - "Does Odylith improve required-path coverage, validation, and expectation success on the live run?"
- The diagnostic lane answers:
  - "Does Odylith build a better grounded packet/prompt than `odylith_off`?"
  - "What is the prep-time and prompt-size cost of Odylith’s retrieval/memory layer?"
  - "Does Odylith improve required-path coverage before the model starts working?"
- Those lanes do not carry equal product weight:
  - `proof` is the governing product benchmark and the primary optimization target
  - `diagnostic` is an internal tuning surface and only counts when it preserves or improves `proof`
  - a diagnostic-only win that harms proof is a benchmark regression
- The supported report modes are `odylith_on`, `odylith_on_no_fanout`,
  `odylith_repo_scan_baseline`, and `raw_agent_baseline`.
- `odylith_off` means `raw_agent_baseline`, and plain-English `Odylith off`
  means the same lane.
- The release-safe primary comparison is `odylith_on` versus
  `raw_agent_baseline`, under the `full_product_assistance_vs_raw_agent`
  comparison contract.
- Older history artifacts may still carry the legacy repo-scan key
  `full_scan_baseline`; report readers must continue to accept it.
- The release-safe default cache profiles are `warm` and `cold`.
- Warm and cold are both part of the published proof because Odylith should be
  fast and robust across first-read and repeated-read posture, not only in the
  easiest cache state.
- `latest.v1.json` is release-safe only when it comes from a full `proof`
  profile run that covers the full corpus, the default live matched pair, and
  both release-safe cache profiles.
- `latest-proof.v1.json` is the profile-specific proof snapshot.
- `latest-diagnostic.v1.json` is the profile-specific diagnostic snapshot.
- `docs/benchmarks/proof/` and `docs/benchmarks/diagnostic/` carry the
  profile-specific SVG graph sets.
- For live proof, `odylith_on` and `odylith_off` must also share the
  same execution contract fields for resolved CLI binary, model, and reasoning
  effort. A report that mixes those contracts is not a valid same-agent
  comparison.
- Scenario validators are part of that same-task fairness contract. Public
  validator commands must target supported `odylith ...` entrypoints, and
  wrapper surfaces such as `odylith subagent-router` and
  `odylith subagent-orchestrator` must preserve their documented
  `--repo-root` and `--help` behavior. A proof result produced while those
  public validator entrypoints are broken is benchmark-debug evidence, not
  trustworthy publication proof.
- The runner may batch the public live pair only after each lane's request has
  already been prepared. Odylith packet-building, cache-profile preparation,
  and other global-state-sensitive phases stay serial. Only the isolated live
  host subprocess phase is allowed to run concurrently, and only for the same
  scenario's `odylith_on` versus `odylith_off` pair.
- Because of that matched-pair batching, published live-proof timing is a
  contention-shared benchmark time-to-valid-outcome measurement, not a
  solo-user latency claim.
- Published live-proof runtime must not collapse to one median-only headline.
  The benchmark contract should publish median plus tail-aware distribution
  context such as mean, `p95`, and full proof pair-wall total across the
  selected cache profiles.
- If Odylith selects docs or contracts for the live evidence cone, those
  surfaces must survive the packet-to-prompt handoff into the live host lane.
  Stripping selected docs from the prompt payload invalidates both required-path
  accuracy claims and prompt-token accounting.
- The inverse also matters on strict bounded proof slices. When the scenario's
  truthful required surface is exactly the listed starting anchors, or the
  family is an exact-path ambiguity probe, the live prompt handoff must strip
  supplemental docs, implementation anchors, and retrieval-plan doc lists
  rather than quietly widening `odylith_on`.
- On those strict bounded proof slices, validator command mentions and
  generated or rendered artifacts are coverage evidence, not approved
  first-pass reads. They only become valid read targets when the listed
  anchors or a focused contradiction point directly at them.
- Strict bounded proof slices must not inherit contradictory widen language
  from broader packet uncertainty. If the slice is marked bounded, the live
  prompt stays local even when the parent packet elsewhere recommended a fuller
  scan.
- Sandbox stripping for `odylith_off` and `odylith_on` may remove only
  auto-consumed instruction entrypoints and tool config surfaces. It must not
  delete truth-bearing repo docs, maintainer markdown, or product skill files
  that remain valid explicit read targets during the task.
- The fairness contract fails closed if `odylith_on` receives undeclared
  preflight evidence, if `odylith_off` loses prompt-visible path attribution
  that the prompt actually showed, or if the report cannot expose those lane
  affordances explicitly.
- If stripped guidance or validator-truth files must reappear before
  validation, they must be restored from a stash captured inside the scoped
  benchmark workspace snapshot, never from the ambient repo root. Restoring
  from repo root reintroduces unrelated dirty state and invalidates proof.
- The shared live-workspace snapshot may not materialize a partial dirty Python
  package. If a dirty selected Python file depends on dirty sibling modules in
  the same package, the snapshot must carry those same-package dirty siblings
  for both compared lanes or fail closed before publication.
- Diagnostic runs must fail closed if any benchmark-owned live host
  subprocess or benchmark temp worktree appears during or after the run.
- Live observed-path attribution must count direct listing, search, and file
  inspection behavior, not transitive file-path mentions embedded inside the
  contents of a different file. Otherwise precision and hallucination metrics
  punish link-dense governance docs instead of actual widening.
- Live proof support-doc selection must prefer the most slice-relevant
  contracts or runbooks before generic guidance surfaces. Generic files such
  as `AGENTS.md`, `agents-guidelines/*`, or skills are valid support docs only
  when they are also the most relevant truthful read for the slice.
- Corpus path semantics must keep grounding recall, supporting evidence, and
  write-surface precision separate. `required_paths` remain the recall target;
  `supporting_paths` are legitimate prompt-visible or command-visible evidence
  that may count as relevant for precision but never satisfy required-path
  recall; `expected_write_paths` are the only authoritative write-target set
  when present, so broad `changed_paths` anchors cannot silently become write
  expectations.
- Manual or case-selected live benchmark runs must execute only the selected
  comparison rows plus required validators. Singleton latency probes and live
  adoption samples are full-corpus publication probes, not hidden fanout for
  focused repro or developer smoke runs.
- Live proof completion recovery must prefer `result.json` but fall back to a
  schema-valid final `agent_message` from the host JSON event stream before
  declaring `missing_schema_output`.

### Published proof posture
- The published view strategy is conservative across the selected cache
  profiles.
- README and the canonical SVG graphs must render from the published summary,
  not from `primary_comparison` or a warm-only slice.
- The public README headline table should center on `odylith_on`,
  and `odylith_off`, while the full tracked report still carries
  `odylith_on_no_fanout` and `odylith_repo_scan_baseline` for internal
  attribution and anti-gaming review.
- Packet and prompt creation diagnostics are useful internal tuning signals,
  but they are not the same thing as the live end-to-end product comparison.
- By default, Odylith applies a conservative `20m` timeout to each live host
  turn so one stalled scenario cannot hang the benchmark indefinitely.
  Validator timeouts remain operator-controlled. Any operator-supplied timeout
  override or explicit disable must be recorded in the report contract.
- The published table must label live-proof timing and token rows honestly:
  time to valid outcome, live agent runtime, validator overhead,
  full-session input, and total model tokens are all distinct measurements.
- Scenario publication must stay same-scenario conservative; it must not mix
  the best baseline case with the worst Odylith case from different cache
  profiles.

### Public evaluation framing
- Odylith should be evaluated first on whether `odylith_on` improves the
  coding outcome versus `raw_agent_baseline` on the same tasks.
- The benchmark is not trying to prove that Odylith beats the base model's
  weights. It is trying to prove that Odylith supplies a better operating
  policy around the same model.
- In benchmark terms, the relevant multipliers are:
  - model capability
  - context quality
  - search policy
  - validation policy
  - recovery policy
- A benchmark win is meaningful only when Odylith improves those control-plane
  terms without changing the underlying same-task model contract.
- The strongest public proof posture is therefore:
  - same repo
  - same truth-bearing surfaces
  - same model and reasoning contract
  - same sandbox and validator contract
  - different result only because `odylith_on` operationalizes the work better
- `odylith_repo_scan_baseline` is still useful because it shows how much the
  repo-scan scaffold itself is helping, but it is not `Odylith off`.
- Structural feature comparisons are secondary context and only meaningful when
  they are tied back to execution consequences.
- Public measured proof is Codex-host-scoped today. Public docs may describe
  Claude-facing benefits from the same grounding and governance layer, but they
  must not overstate those benefits as Claude-host benchmark proof until that
  proof exists.
- If Odylith only wins when it gets extra hidden truth, that is a weaker story
  than the true benchmark claim and must not be presented as the primary
  proof.
- The benchmark therefore prefers declared product advantages over pretend
  symmetry. If an affordance is intentional Odylith behavior, document it in
  the comparison contract and report it explicitly; do not hide it behind a
  narrower public claim.
- If `odylith_on` beats `odylith_off` when both lanes can explicitly read the
  same truthful repo surfaces, then Odylith has demonstrated real systems
  value rather than a hidden-information advantage.

### Metrics that matter
Odylith treats benchmark outcome priorities in this order:
1. correctness and non-regression
2. grounding recall and precision
3. validation success and execution fit
4. robustness and consistency across cache states, retries, and recoveries
5. time to a valid outcome
6. prompt-token and total payload efficiency
7. bounded performance under tighter token budgets

In practice that means:
- correctness and non-regression:
  task acceptance, critical validation success, no collateral breakage, and no
  hidden damage to the repo or runtime contract
- grounding recall and precision:
  required-path recall, required-path precision, evidence sufficiency, and low
  hallucinated-surface drift
- validation success and execution fit:
  valid-answer rate, expectation success, write-surface precision, and
  adherence to the intended execution posture
- robustness and consistency:
  warm-plus-cold consistency, rerun stability, bounded recovery after stale or
  ambiguous state, and fail-closed behavior when Odylith cannot ground safely
- time to a valid outcome:
  speed only matters after Odylith is still right, grounded, and safe; on the
  live proof lane this is benchmark time to valid outcome, not solo-user
  latency
- prompt-token and total payload efficiency:
  on the live proof lane these are full-session host-session costs; initial
  prompt-bundle efficiency belongs to the diagnostic lane
- bounded token-budget behavior:
  Odylith should degrade gracefully under tighter budgets rather than winning
  only in generous-token conditions

Benchmark improvement only counts as a real product win when Odylith preserves
or improves the higher-tier quality metrics while keeping the lower-tier speed
and efficiency metrics inside explicit guardrails. Faster or cheaper but less
correct, less grounded, or less reliable is not accepted as product progress.

Publication and release status use these layers:
- `hard quality gate`:
  correctness/non-regression, grounding recall/precision, validation/fit, and
  robustness/consistency all hold the status immediately if they regress
- `secondary guardrails`:
  packet-backed live-proof tighter-budget behavior remains status-blocking;
  architecture-only or other non-packet sampled slices do not fail this
  guardrail just because no packet rows are present; time to valid outcome and
  full-session token cost stay published as diagnostics because they do not
  share the measurement basis of solo-user latency or initial prompt size
- comparative latency and prompt or payload guardrails are only status
  blockers when the compared lanes share the same measurement basis; a failed
  baseline that exits faster or cheaper stays published as a diagnostic, not
  as a blocker
- the candidate-side `within_budget_rate` floor still applies on packet-backed
  sampled slices even when the relative efficiency guardrails are not active
- `advisory mechanism checks`:
  packet coverage, widening frequency, route posture, and related mechanism
  metrics stay published for diagnosis, but they are not the same thing as the
  primary outcome gate by themselves

Current live-proof secondary guardrail:
- `within_budget_rate` must stay at or above `0.80` on packet-backed sampled slices

Current diagnostic-lane efficiency guardrails:
- median prompt-bundle delta must stay at or below `+64 tokens`
- median total-payload delta must stay at or below `+96 tokens`

Supporting measures such as grounded delegation rate, route-ready rate,
expectation success, and operating-posture metrics matter because they explain
how Odylith achieved the result, not just what the scoreboard says.

### Eval quality gates
The benchmark itself is only trustworthy when it also measures the right shape
of work:
- scenario coverage must span small, medium, and large or complex repo work
- coverage must include single-file, cross-file, and cross-surface tasks
- coverage must include correctness-sensitive and recovery-sensitive cases
- the published proof must remain conservative across warm and cold profiles
- singleton sensitive-family latency must not be published from a single noisy
  wall-clock sample when rerun-stability probes disagree
- faster failure must never be treated as a lower-tier benchmark win over a
  slower correct outcome
- benchmark evolution must make the corpus harder, more realistic, or more
  reproducible, never easier

Release-safe benchmark status is distinct from these eval-integrity gates:
- warm and cold cache profiles must both clear the hard quality gate
- when both compared lanes produce successful outcomes, the published
  comparison must also stay inside the explicit lower-tier guardrails above
- advisory mechanism debt must still be published honestly even when it is not
  the direct status blocker

## Cross-Component Control Flow
### 1. Define the benchmark workload
1. The benchmark corpus specifies canonical `scenarios` and
   `architecture_scenarios`, plus workstream anchors, expectations, and
   validation hooks.
2. Registry, Radar, Atlas, and spec truth keep those scenarios grounded in the
   live product.

### 2. Run the benchmark
1. The benchmark runner executes the selected cache profiles for
   `odylith_on`, `odylith_on_no_fanout`, `odylith_repo_scan_baseline`, and
   `raw_agent_baseline`.
2. `odylith_on` measures the real [Odylith Context Engine](../odylith-context-engine/CURRENT_SPEC.md)
   and [Subagent Orchestrator](../subagent-orchestrator/CURRENT_SPEC.md)
   posture used by the product.
3. The runner writes the latest report and an immutable history artifact under
   `.odylith/runtime/odylith-benchmarks/`, including first-class
   `published_summary`, `published_family_deltas`, `published_mode_table`,
   `tracked_mode_table`, and `robustness_summary` fields for publication and
   internal review consumers.
4. Sensitive singleton families must also record rerun-stability probes with
   fresh same-profile cache preparation and publish family latency from the
   median-of-N probe samples instead of one potentially noisy wall-clock hit.
5. Packet results must publish traced reasoning time plus explicit
   uninstrumented overhead so latency spikes can be diagnosed instead of being
   mistaken for grounding-quality regressions.
6. Live proof-host CLI results must also publish the isolation contract that
   made the comparison fair, including whether the run used a temporary host
   home,
   stripped repo guidance, localized validator cache or temp roots, the
   resolved timeout policy, and any remaining contamination risks that still
   invalidate publication.
7. Lane-emitted workspace paths are untrusted input. Invalid or impossible
   path tokens must fail closed into missing attribution rather than crashing
   the benchmark harness.
8. Targeted `proof` reruns such as `--profile proof --case-id ...` remain
   honest tuning slices for the live contract, but they are not release-safe
   publication replacements for the full warm-plus-cold proof lane.

### 3. Publish the proof
1. The graph renderer consumes the latest published report.
2. Maintainer release proof regenerates the README SVG assets and benchmark
   snapshot from that same report.
3. Public benchmark docs and reviewer guidance must stay aligned with that same
   report and the benchmark priority order.
4. The release lane should treat stale graphs, stale README numbers, or stale
   benchmark-framing docs as a publication failure, not as optional polish.

## What Developers Need To Change Together
- Corpus changes:
  update the canonical `scenarios` / `architecture_scenarios` corpus, related
  workstreams, validation hooks, and any benchmark docs or publication
  snapshots that derive from the changed scenarios.
- New benchmark metric:
  update the runner, report summary, graph renderer, and README publication
  wording together so the public proof does not drift from the machine-readable
  report.
- Publication-contract change:
  update the runner, graph renderer, README benchmark section, benchmark docs,
  reviewer guide, and maintainer release guidance in the same slice.
- Public evaluation-frame change:
  update README framing, benchmark explainer, reviewer guidance, and component
  truth together so the benchmark-first comparison contract does not drift back
  toward surface-inventory storytelling.

## Failure And Integrity Posture
- The benchmark must fail closed on broken corpus truth, broken validator
  contracts, or unreadable report inputs.
- Broken public validator wrappers are product failures, not benchmark noise.
  If a documented `odylith ...` validator command misparses, the fix belongs in
  the product command surface before the benchmark story moves forward.
- The benchmark must also fail closed on contaminated live-run isolation. If
  the raw-host lane still sees shared workstation or repo state, the result is
  debug-only and must not be narrated as benchmark proof.
- The tracked corpus stays canonical on `scenarios` and
  `architecture_scenarios`; reader support for legacy `cases` keys is only a
  backward-compatibility bridge, not the maintained source-truth shape.
- Odylith must not cherry-pick only the easiest cache profile for publication.
- README and graph publication must not claim a result stronger than the latest
  conservative published report.
- Public docs and reviewer guidance must not drift into treating structural
  overlap or feature-parity tables as the primary proof of product value.
- Odylith must not gain benchmark wins from weakened workload shape, stale
  projection truth, or cross-scenario comparison tricks.
- Historical integrity failures now tracked in Casebook are part of the
  benchmark safety model:
  - `CB-027` records the open live-run contamination and raw-baseline isolation
    gap.
  - `CB-028` records the fixed false-pass gate that previously allowed both
    failed lanes to look provisionally green.
- A slower but more honest benchmark lane is preferable to a flattering but
  weakly grounded benchmark story.
- A faster or cheaper benchmark result that regresses recall, accuracy, or
  precision is also a failure, even if the speed or token headline improves.
- Warm-only or profile-scoped local runs remain useful for debugging, but they
  are not release-safe publication proof unless the report says otherwise.

## Validation Playbook
### Runtime proof
- `odylith benchmark --repo-root .`
- `odylith benchmark --repo-root . --profile proof`
- `PYTHONPATH=src python -m odylith.runtime.evaluation.odylith_benchmark_graphs --report .odylith/runtime/odylith-benchmarks/latest.v1.json --out-dir docs/benchmarks`

### Focused tests
- `PYTHONPATH=src python -m pytest -q tests/unit/runtime/test_odylith_benchmark_runner.py tests/unit/runtime/test_odylith_benchmark_graphs.py tests/unit/test_cli.py`
- `python -m pytest -q tests/unit/runtime/test_tooling_guidance_catalog.py tests/unit/runtime/test_tooling_context_retrieval_guidance.py tests/unit/runtime/test_odylith_benchmark_prompt_regressions.py tests/unit/runtime/test_odylith_benchmark_preflight.py`
- `odylith validate guidance-behavior --repo-root .`

## Requirements Trace
This section captures synchronized requirement and contract signals derived from component-linked timeline evidence.

<!-- registry-requirements:start -->
- **2026-04-17 · Implementation:** B-110 Odylith Discipline hardening centralized signal/law policy, ranked open-world affordances, suppressed ephemeral practice refs, tagged Discipline benchmark scenarios to B-110, and proved zero-credit validators plus quick benchmark families with advisory widening at 0.0.
  - Scope: B-110
  - Evidence: odylith/runtime/source/optimization-evaluation-corpus.v1.json, odylith/technical-plans/in-progress/2026-04/2026-04-17-adaptive-discipline-credit-safe-and-benchmark-proved.md
- **2026-04-05 · Implementation:** Refreshed the benchmark publication story to the April 5 source-local full proof pass 52aa3f76538cf12f: README, benchmark docs, registry spec, plans, and radar now reflect that odylith_on clears the hard gate and secondary guardrails against odylith_off while benchmark_compare still warns until the first shipped release baseline exists.
  - Scope: B-021, B-022
  - Evidence: README.md, docs/benchmarks/README.md +3 more
<!-- registry-requirements:end -->

## Feature History
- 2026-03-28: Added a first-class local benchmark corpus and proof lane that cleared the initial provisional benchmark gate to `provisional_pass` and refreshed the public README snapshot from real measured behavior. (Plan: [B-009](odylith/radar/radar.html?view=plan&workstream=B-009))
- 2026-03-29: Tightened the benchmark frontier by compacting hot-path overhead, reran the Codex corpus, and regenerated the canonical README graph set from the stronger report. (Plan: [B-019](odylith/radar/radar.html?view=plan&workstream=B-019))
- 2026-03-29: Hardened benchmark integrity with warm-plus-cold conservative publication, explicit published-summary fields, and release-safe README or graph proof driven from the harder benchmark view. (Plan: [B-020](odylith/radar/radar.html?view=plan&workstream=B-020))
- 2026-04-01: Reframed the benchmark component around a real same-model live host CLI comparison, documented the strict isolation contract for `odylith_off`, and recorded the false-pass, contamination, prompt-boundary selected-doc loss, over-stripped worktree truth-loss, and transitive-link attribution failure modes discovered during the honest raw-baseline redesign. (Plan: [B-022](odylith/radar/radar.html?view=plan&workstream=B-022))
- 2026-04-02: Fixed the public subagent validator wrapper contract so proof can call documented `odylith subagent-router` and `odylith subagent-orchestrator` commands without repo-root parse failures, and recorded the resulting validator-backed targeted proof rerun against the honest warm slice. (Plan: [B-022](odylith/radar/radar.html?view=plan&workstream=B-022))
- 2026-04-02: Tightened the clean-room proof boundary again by restoring validator truth only from the scoped workspace snapshot and by expanding the shared snapshot allowlist to dirty same-package Python siblings needed for imports, so disposable worktrees stop rehydrating unrelated repo state or failing on partial local packages. (Plan: [B-022](odylith/radar/radar.html?view=plan&workstream=B-022))
- 2026-04-02: Clarified that benchmark wins are meaningful only when Odylith improves the operating policy around the same model under the same repo and same truth contract, and explicitly documented the weaker status of wins that depend on extra hidden information. (Plan: [B-022](odylith/radar/radar.html?view=plan&workstream=B-022))
- 2026-04-05: Restored canonical benchmark guidance memory, made weak-family packet shaping fail closed before prompt rendering, bounded the post-run adoption-proof finalizer so it cannot hold a completed report hostage, and refreshed the current local-memory-first source-local proof to `52aa3f76538cf12f` `provisional_pass` while the diagnostic grounding floor remains `74cbe36427f2c375` on `hold`. (Plan: [B-021](odylith/radar/radar.html?view=plan&workstream=B-021))
- 2026-04-08: Completed the reasoning-package boundary split with no compatibility shims, refreshed Atlas and delivery-intelligence sync truth to the new reasoning paths, and re-proved the quick source-local architecture shard to `provisional_pass` after the package-separation hardening. (Plan: [B-061](odylith/radar/radar.html?view=plan&workstream=B-061))
- 2026-04-17: Added the `guidance_behavior` benchmark family, source corpus, bundle-mirror check, and validator command so high-risk guidance behavior is measured separately from intervention-value calibration and cannot be mistaken for ML-quality selector training data. (Plan: [B-096](odylith/radar/radar.html?view=plan&workstream=B-096); Bug: `CB-123`)
- 2026-04-17: Bound the `guidance_behavior` benchmark/eval path into `odylith_guidance_behavior_platform_end_to_end.v1`, so quick-family selection, low-latency support-doc policy, benchmark isolation, host mirrors, consumer bundle assets, and install guidance are validated as one platform proof contract. (Plan: [B-096](odylith/radar/radar.html?view=plan&workstream=B-096); Bug: `CB-123`)
- 2026-04-17: Added the `hot_path_efficiency` domain to Guidance Behavior platform proof and re-proved the quick family at `6` scenarios, `0.0` widening rate, no advisory failures, and Odylith ON packet timing of `median=5.712 ms`, `avg=5.999 ms`, `p95=7.463 ms`. (Plan: [B-096](odylith/radar/radar.html?view=plan&workstream=B-096); Bug: `CB-123`)
- 2026-04-17: Hardened Guidance Behavior platform proof so stale live/source-bundle mirrors for guidance docs, host shims, skills, governed program/spec truth, and benchmark corpora fail validation instead of passing on token-present but lane-divergent consumer assets. (Plan: [B-096](odylith/radar/radar.html?view=plan&workstream=B-096); Bug: `CB-123`)
- 2026-04-18: Expanded Odylith Discipline benchmark sovereignty from scenario selection into contract-quality metrics: pressure observations, affordances, admissibility, proof obligations, learning replay, memory recurrence, intervention visibility, and platform integration now feed deterministic summary rates while provider and host-model call counts stay zero. (Plan: [B-110](odylith/radar/radar.html?view=plan&workstream=B-110))
